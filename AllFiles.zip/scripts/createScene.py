# import burg_toolkit as burg
# dim = (0.297,0.297)
# object_library = burg.ObjectLibrary.from_yaml('../examples/object_library/example_library_roundtrip.yaml')
# scene_fn='../examples/scenes/myscene.yaml'
# n_instances = min(5, len(object_library))
# print(f'{n_instances} instances will be placed in ground area of {dim}')
# # wait_for_user(skip)
# scene = burg.sampling.sample_scene(
#     object_library,
#     ground_area=dim,
#     instances_per_scene=n_instances,
#     instances_per_object=1
# )
# burg.visualization.show_geometries([scene])
# scene.to_yaml(scene_fn,object_library)
import burg_toolkit as burg
import argparse
import numpy as np
from matplotlib import pyplot as plt

FRAME_SIZE = 0.03
dim = (0.297, 0.297)

# object_library = burg.ObjectLibrary.from_yaml('../examples/object_library/example_library_roundtrip.yaml')
object_library = burg.ObjectLibrary.from_yaml('../examples/ycb_object_library/object_library.yaml')
n_instances = min(5, len(object_library))

def createScenes(indexValue):
    scene_fn = f'../examples/New_Scenes_Dataset/myscene_{indexValue+1}.yaml'
    scene = burg.sampling.sample_scene(
        object_library,
        ground_area=dim,
        instances_per_scene=n_instances,
        instances_per_object=1
    )
    # burg.visualization.show_geometries([scene])
    scene.to_yaml(f'{scene_fn}', object_library)  # Save scene with a unique filename
    return scene_fn

def parse_args(filePath):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scene', type=str,
                        default=filePath,
                        help='path to a scene file')
    return parser.parse_args()
def sample_complete_point_clouds(scene):

    mesh = scene.objects[1].get_mesh()
    point_cloud = burg.mesh_processing.poisson_disk_sampling(mesh, radius=0.006)#radius=0.003
    # burg.visualization.show_geometries([scene, point_cloud])

    remaining_objects = scene.objects
    remaining_objects1 = scene.objects
    # burg.visualization.show_geometries([scene, point_cloud])
    meshes = scene.get_mesh_list(with_plane=False)

    point_clouds = []
    for mesh in meshes:
        point_cloud = burg.mesh_processing.poisson_disk_sampling(mesh)
        point_clouds.append(point_cloud)
    # burg.visualization.show_geometries(point_clouds)  # point_clouds are already in a list, so we can skip the brackets
def create_point_clouds_from_depth_images(scene):
    camera = burg.render.Camera.create_kinect_like()
    camera_position = [0.0, 0.0, 0.2]
    camera_pose = np.eye(4)  # this is the identity matrix
    camera_pose[:3, 3] = camera_position
    scene_origin_vis = burg.visualization.create_frame(size=FRAME_SIZE, pose=np.eye(4))
    camera_vis = burg.visualization.create_frame(size=FRAME_SIZE, pose=camera_pose)
    # burg.visualization.show_geometries([scene, camera_vis, scene_origin_vis])

    target = [scene.ground_area[0]/2, scene.ground_area[1]/2, 0.05]
    camera_pose = burg.util.look_at(camera_position, target, flip=True)

    # and visualise
    camera_vis = burg.visualization.create_frame(size=FRAME_SIZE, pose=camera_pose)
    # burg.visualization.show_geometries([scene, camera_vis, scene_origin_vis])

    render_engine = burg.render.PyBulletRenderEngine()  # requires urdf + vhacd
    render_engine.setup_scene(scene, camera, with_plane=True)  # we can also disable the plane
    rgb_image, depth_image = render_engine.render(camera_pose)  # later, we can re-use the render engine to create more

    _, ax = plt.subplots(1, 2)
    ax[0].imshow(rgb_image)
    ax[1].imshow(depth_image)
    # plt.show()

    point_cloud = camera.point_cloud_from_depth(depth_image, camera_pose)

    # burg.visualization.show_geometries([point_cloud, camera_vis, scene_origin_vis])

def pointCloudRendering(filePath):
    args = parse_args(filePath)
    scene, lib, _ = burg.Scene.from_yaml(args.scene)
    # burg.visualization.show_geometries([scene])
    sample_complete_point_clouds(scene)
    create_point_clouds_from_depth_images(scene)

for i in range(100):
    filePath=createScenes(i)
    pointCloudRendering(filePath)
    # print(i+1)
print('Done!!')