.. Grasp Data Toolkit documentation master file, created by
   sphinx-quickstart on Thu Feb  4 18:09:54 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to BURG Toolkit's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   burg_toolkit


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


.. mdinclude:: ../readme.md

